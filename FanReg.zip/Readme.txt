Board specs - 

2 layer board, 1oz outer copper
0.062" thickness
HASL board finish
Green soldermask

Layer definitions - 

assemblytop.pho - Assembly drawing (derived from board top)
assemblybottom.pho - Assembly drawing (derived from board bottom)
bottomcopper.pho - Bottom copper layer
bottompastemask.pho - Bottom Paste Mask layer
bottomsilkscren.pho - Bottom Silk Screen layer
bottomsoldermask.pho - Bottom Solder Mask layer
drilldrawing.pho - Drill Drawing
drills.drl - Drill File
topcopper.pho - Top copper payer
toppastemask.pho - Top Paste Mask layer
topsilkscreen.pho - Top Silk Screen layer
topsoldermask.pho - Top Solder Mask layer

Included files -

FanReg_BOM.xlsx
FanReg_XYRS.xlsx
